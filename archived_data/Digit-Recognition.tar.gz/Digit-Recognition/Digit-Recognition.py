#Required libraires

from keras.datasets import mnist
from keras.utils import to_categorical
from keras import layers
from keras import models

#loading the mnist data set
print("loading the data....")
(train_images, train_labels),(test_images, test_labels) = mnist.load_data()


#reshaping the training data
train_images = train_images.reshape(60000, 28, 28, 1)
train_images = train_images.astype('float32')/255

#Applying min max scaling on both training and testing data.
test_images = test_images.reshape(10000, 28, 28, 1)
test_images = test_images.astype('float32')/255

#converting the labels into one format
train_labels = to_categorical(train_labels)
test_labels = to_categorical(test_labels)

#desgning the cnn model
model = models.Sequential()
model.add(layers.Conv2D(32, (3,3), activation='relu', input_shape=(28, 28, 1)))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(16, (5,5), activation="relu"))
model.add(layers.MaxPooling2D(2, 2))

#Applying flattening and adding last layers of the model

model.add(layers.Flatten())
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dense(10, activation='softmax'))


#Compiling the model
print("Compiling the modal...")
model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(train_images, train_labels, epochs=50, batch_size=64)


#loading the model into a h5 file.
#serialize model to json
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)

    #serialize weight to HDF5
model.save_weights("model.h5")
print("Saved models to disk")

#store the answers in a variable
answer = model.predict(test_images)

#import the confusion matrix
from sklearn.metrics import confucion_matrix


#The np.argmax function will select the index at which maximum value #is present. Here this max value it the maximum probability of a 
#class being the answer

final_pred = np.argmax(answer, axis=-1)

#make the matrix and store in a new variable
matrix = confusion_matrix(test_labels.argmax(axis=1), final_pred)



